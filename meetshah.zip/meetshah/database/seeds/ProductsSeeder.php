<?php

use Illuminate\Database\Seeder;

class ProductsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        \DB::table('products')->insert([
            'name' => 'Travel Bagpack',
            'description' => 'WATER RESISTANT WITH 1 YEAR WARRANTY - Stylish and durable backpack for school /college, daily casual use and travel. . Size: 18.5 inch X 13.5 inch X 9 inch.',
            'photo' => '14.png',
            'price' => 92.00
        ]);
        \DB::table('products')->insert([
            'name' => 'Earphones',
            'description' => 'The stylish BassHeads 100 superior coated wired earphones are a definite fashion statement - wear your attitude with its wide variety of collection',
            'photo' => '6.jpg',
            'price' => 129.99
        ]);
        \DB::table('products')->insert([
            'name' => 'Samsung Galaxy S9',
            'description' => 'A brand new, sealed Lilac Purple Verizon Global Unlocked Galaxy S9 by Samsung. This is an upgrade. Clean ESN and activation ready.',
            'photo' => '55.png',
            'price' => 698.88
         ]);
         \DB::table('products')->insert([
             'name' => 'Apple iPhone X',
             'description' => 'GSM & CDMA FACTORY UNLOCKED! WORKS WORLDWIDE! FACTORY UNLOCKED. iPhone x 64gb. iPhone 8 64gb. iPhone 8 64gb. iPhone X with iOS 11.',
             'photo' => '2.png',
             'price' => 983.00
         ]);
         \DB::table('products')->insert([
             'name' => 'Google Pixel 2 XL',
             'description' => 'New condition
 • No returns, but backed by eBay Money back guarantee',
             'photo' => '3.jpg',
             'price' => 675.00
         ]);
         \DB::table('products')->insert([
             'name' => 'LG V10 H900',
             'description' => 'NETWORK Technology GSM. Protection Corning Gorilla Glass 4. MISC Colors Space Black, Luxe White, Modern Beige, Ocean Blue, Opal Blue. SAR EU 0.59 W/kg (head).',
             'photo' => '4.jpg',
             'price' => 159.99
         ]);
         \DB::table('products')->insert([
             'name' => 'Huawei Elate',
             'description' => 'Cricket Wireless - Huawei Elate. New Sealed Huawei Elate Smartphone.',
             'photo' => '5.jpg',
             'price' => 68.00
         ]);
         \DB::table('products')->insert([
             'name' => 'HTC One M10',
             'description' => 'The device is in good cosmetic condition and will show minor scratches and/or scuff marks.',
             'photo' => '6.jpg',
             'price' => 129.99
         ]);
         \DB::table('products')->insert([
            'name' => 'Echo Dot (3rd Gen)',
            'description' => 'Echo Dot is our best selling smart speaker that can be operated by voice - even from a distance. Alexa can speak both English & Hindi, and new features are added automatically',
            'photo' => '16.png',
            'price' => 1199.00
        ]);
        \DB::table('products')->insert([
            'name' => 'Electric Kettle',
            'description' => 'Max 3 differentiators Great Features - i)Automatic Cutoff ii) 360 Degree Swivel Base iii)Single Touch lid locking',
            'photo' => '19.png',
            'price' => 599.00
        ]);
    }
}
