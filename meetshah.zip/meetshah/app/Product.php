<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $table = 'products';
    protected $fillable = ['seller_id','name','description','photo','price','category_id','subcategory_id','status'];

    public function prodCategory() {
        return $this->belongsTo('App\Category','category_id','id');
    }

    public function subcategory() {
        return $this->belongsTo('App\Subcategory','subcategory_id','id');
    }
}
