<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
    protected $table = 'orders';
    protected $fillable = ['user_id','token','product_id','product_name','product_description','unit_price','image','quantity','status','added_at','purchased_at','total_price'];
}
