<?php

use App\Order;

function getcart() {
    $user_id = auth()->user()->id;
    $cart_items = Order::where('user_id',$user_id)->where('status',1)->get();
    return $cart_items;
}

?>