<?php

namespace App\Http\Controllers\seller;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Product;
use Auth;
use DataTables;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('seller.product.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getproducts(Request $request) {

        $products = Product::where('status','active')->orderby('id','desc');
        
        $products = $products->with('prodCategory','subcategory')->get();

        /*echo "<pre>";
        print_r($products);
        die;*/

        return DataTables::of($products)
        
        ->addColumn('category', function ($q) {
            return $q->prodCategory->name;
        })

        ->addColumn('subcategory', function ($q) {
            return $q->subcategory->name;
        })

        ->addColumn('image', function ($q) {
            //return $q->subcategory;
            return "<img src='".asset('public/product_media/'.$q['photo'])."' style='width: 100px;'>";
        })

        ->addColumn('action', function ($q) {
            $id = encrypt($q->id);
            return '<a style="color:#000;" title="Edit"  href="'.route('seller.product.edit',[$id]).'"><i class="fa fa-pencil"></i></a> | <a title="'.__('message.Delete').'" class="delete_product" data-id="' . $id . '"><i class="fa fa-trash"></i></a>';
        })
        ->addColumn('name', function ($q) {
            return $q->name;
        })
        ->addIndexColumn()
        ->rawColumns([ 'action','image'])->make(true);
    }
}
