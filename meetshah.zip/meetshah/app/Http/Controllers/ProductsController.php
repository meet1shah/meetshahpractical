<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use App\Product;
use App\Order;
use Auth;

class ProductsController extends Controller
{
    //
    public function __construct() {
        $this->middleware('auth');
    }
    
    public function index()
    {
        $products = Product::all();
        return view('products', compact('products'));
    }
    public function cart()
    {
        return view('cart');
    }
    
    public function addToCart($id)
    {
        try {
            $Product = Product::find($id);
            if(!$Product) {
                abort(404);
            }
            $Order = new Order;
            $Order->user_id = Auth::user()->id;
            $Order->product_id = $Product->id;
            $Order->product_name = $Product->name;
            $Order->product_description = $Product->description;
            $Order->unit_price = $Product->price;
            $Order->total_price = $Product->price * 1;
            $Order->image = $Product->photo;
            $Order->quantity = 1;
            $Order->status = 1;
            $Order->added_at = date("Y-m-d H:i:s");
            $Order->save();
            DB::commit();
            return redirect()->back()->with('success', 'Product added to cart successfully!');
            // if cart not empty then check if this product exist then increment quantity
        } catch (\Exception $e) {
            return view('error');
        }
    }

    public function update(Request $request)
    {
        if($request->id and $request->quantity)
        {
            $order = Order::find($request->id);
            $order->quantity = $request->quantity;
            $order->save();
            session()->flash('success', 'Cart updated successfully');
        }
    }
    public function remove(Request $request)
    {
        if($request->id) {
            $order = Order::find($request->id);
            $order->delete();
            session()->flash('success', 'Product removed successfully');
        }
    }

    public function checkout(Request $request) {
        try {
            $user_id = auth()->user()->id;
            $cart_items = Order::where('user_id',$user_id)->where('status',1)->update(['status'=>2]);
            $products = Order::where('user_id',$user_id)->where('status',2)->get();
            //session()->forget('cart');
            return view('checkout', compact('products'));

        } catch (\Exception $e) {
            return view('error');
        }
    }

    public function clearcart(Request $request) {
        session()->forget('cart');
        return redirect('/');
    }

    public function confirmorder(Request $request) {
        session()->forget('cart');
        $token = $_COOKIE["user_token"];
        $products = Order::where('token',$token)->update(['status'=>2]);
        return redirect('/');
    }

    public function myorder(Request $request) {
        $user_id = auth()->user()->id;
        $products = Order::where('user_id',$user_id)->where('status',2)->get();
        return view('myorder', compact('products'));
    }
}
