<?php

namespace App\Http\Middleware;

use Closure;

class CheckPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $permission)
    {

        if($request->user()->role != $permission){
            \Auth::guard('web')->logout();
            \Session::flash('status', 'Error!');
            \Session::flash('alert-class', 'text-danger');
            \Session::flash('message', 'Your account is inactive please contact to administration.');
            return redirect('/login');
        }
        return $next($request);
    }
}
