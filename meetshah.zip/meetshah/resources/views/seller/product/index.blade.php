@extends('layout.layout')

@section('content')
<div class="row">

    <div class="col-lg-12">
        <div class="ibox ">
            
            <div class="ibox-content nopaddingleftright">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover datasample" >
                    <thead>
                        <tr>
                            <th>Thumb</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Sub Category</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@push('scripts')
<script>
    $(document).ready(function(){
        $('.datasample').DataTable({
           processing: true,
           serverSide: true,
           stateSave: true,
           ajax: {
               'url': "{{ route('seller.getproducts') }}",
               'type': 'POST',
               'data': function ( d ) {
                   d._token = "{{ csrf_token() }}";

               },
               complete: function() {
                    
               },
           },
           columns: [
           { data: 'image',"orderable": false,"searchable": false},
           { data: 'name'},
           { data: 'category'},
           { data: 'subcategory'},
           { data: 'action',"orderable": false,"searchable": false},

           ]
       });
    });
</script>
@endpush
@endsection