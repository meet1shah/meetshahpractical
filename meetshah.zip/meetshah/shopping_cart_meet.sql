-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2022 at 06:20 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Bags', 'active', '2022-02-22 04:35:37', NULL),
(2, 'Home Appliances', 'active', '2022-02-22 04:35:37', NULL),
(3, 'Electronics', 'active', '2022-02-22 04:37:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2022_02_16_025716_create_products_table', 1),
(4, '2022_02_16_034115_create_orders_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `token` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_price` double(8,2) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` double(8,2) NOT NULL,
  `status` smallint(6) NOT NULL,
  `added_at` timestamp NULL DEFAULT NULL,
  `purchased_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `token`, `product_id`, `product_name`, `product_description`, `unit_price`, `image`, `quantity`, `total_price`, `status`, `added_at`, `purchased_at`, `created_at`, `updated_at`) VALUES
(2, 2, NULL, 3, 'Samsung Galaxy S9', 'A brand new, sealed Lilac Purple Verizon Global Unlocked Galaxy S9 by Samsung. This is an upgrade. Clean ESN and activation ready.', 698.88, '55.png', 3, 698.88, 2, '2022-02-21 12:23:03', NULL, '2022-02-21 12:23:03', '2022-02-21 12:52:57'),
(4, 2, NULL, 8, 'HTC One M10', 'The device is in good cosmetic condition and will show minor scratches and/or scuff marks.', 129.99, '6.jpg', 1, 129.99, 2, '2022-02-21 12:32:00', NULL, '2022-02-21 12:32:00', '2022-02-21 12:52:57'),
(5, 2, NULL, 1, 'Travel Bagpack', 'WATER RESISTANT WITH 1 YEAR WARRANTY - Stylish and durable backpack for school /college, daily casual use and travel. . Size: 18.5 inch X 13.5 inch X 9 inch.', 92.00, '14.png', 1, 92.00, 2, '2022-02-21 12:53:56', NULL, '2022-02-21 12:53:56', '2022-02-21 12:54:14'),
(6, 2, NULL, 7, 'Huawei Elate', 'Cricket Wireless - Huawei Elate. New Sealed Huawei Elate Smartphone.', 68.00, '5.jpg', 1, 68.00, 1, '2022-02-21 12:54:42', NULL, '2022-02-21 12:54:42', '2022-02-21 12:54:42'),
(7, 2, NULL, 1, 'Travel Bagpack', 'WATER RESISTANT WITH 1 YEAR WARRANTY - Stylish and durable backpack for school /college, daily casual use and travel. . Size: 18.5 inch X 13.5 inch X 9 inch.', 92.00, '14.png', 1, 92.00, 1, '2022-02-21 13:13:38', NULL, '2022-02-21 13:13:38', '2022-02-21 13:13:38');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `seller_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(6,2) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `seller_id`, `name`, `description`, `photo`, `price`, `category_id`, `subcategory_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Travel Bagpack', 'WATER RESISTANT WITH 1 YEAR WARRANTY - Stylish and durable backpack for school /college, daily casual use and travel. . Size: 18.5 inch X 13.5 inch X 9 inch.', '14.png', '92.00', 1, 1, 'active', NULL, NULL),
(2, 3, 'Earphones', 'The stylish BassHeads 100 superior coated wired earphones are a definite fashion statement - wear your attitude with its wide variety of collection', '6.jpg', '129.99', 3, 4, 'active', NULL, NULL),
(3, 1, 'Samsung Galaxy S9', 'A brand new, sealed Lilac Purple Verizon Global Unlocked Galaxy S9 by Samsung. This is an upgrade. Clean ESN and activation ready.', '55.png', '698.88', 3, 3, 'active', NULL, NULL),
(4, 1, 'Apple iPhone X', 'GSM & CDMA FACTORY UNLOCKED! WORKS WORLDWIDE! FACTORY UNLOCKED. iPhone x 64gb. iPhone 8 64gb. iPhone 8 64gb. iPhone X with iOS 11.', '2.png', '983.00', 3, 3, 'active', NULL, NULL),
(5, 1, 'Google Pixel 2 XL', 'New condition\n • No returns, but backed by eBay Money back guarantee', '3.jpg', '675.00', 3, 3, 'active', NULL, NULL),
(6, 1, 'LG V10 H900', 'NETWORK Technology GSM. Protection Corning Gorilla Glass 4. MISC Colors Space Black, Luxe White, Modern Beige, Ocean Blue, Opal Blue. SAR EU 0.59 W/kg (head).', '4.jpg', '159.99', 3, 3, 'active', NULL, NULL),
(7, 3, 'Huawei Elate', 'Cricket Wireless - Huawei Elate. New Sealed Huawei Elate Smartphone.', '5.jpg', '68.00', 3, 3, 'active', NULL, NULL),
(8, 3, 'HTC One M10', 'The device is in good cosmetic condition and will show minor scratches and/or scuff marks.', '6.jpg', '129.99', 3, 3, 'active', NULL, NULL),
(9, 3, 'Echo Dot (3rd Gen)', 'Echo Dot is our best selling smart speaker that can be operated by voice - even from a distance. Alexa can speak both English & Hindi, and new features are added automatically', '16.png', '1199.00', 3, 4, 'active', NULL, NULL),
(10, 1, 'Electric Kettle', 'Max 3 differentiators Great Features - i)Automatic Cutoff ii) 360 Degree Swivel Base iii)Single Touch lid locking', '19.png', '599.00', 2, 2, 'active', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'College Bags', 'active', '2022-02-22 04:36:10', NULL),
(2, 2, 'Kitchen Appliance', 'active', '2022-02-22 04:36:34', NULL),
(3, 3, 'Mobiles', 'active', '2022-02-22 04:37:29', NULL),
(4, 3, 'Mobile Accessories', 'active', '2022-02-22 04:37:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('shop','user') COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` enum('en','nl') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `currency` enum('USD','EUR') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `username`, `language`, `currency`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Shop1', 'shop1@devrepublic.nl', NULL, '$2y$10$BpmDYtF4R2hdGP8kE9DiTeblAYnp9xeOjDRm/Y3Bb3cIrnIjL0ADq', 'shop', NULL, 'en', 'USD', NULL, '2022-02-21 10:53:30', '2022-02-21 10:53:30'),
(2, 'User1', 'user1@devrepublic.nl', NULL, '$2y$10$BpmDYtF4R2hdGP8kE9DiTeblAYnp9xeOjDRm/Y3Bb3cIrnIjL0ADq', 'user', 'user1', 'nl', 'USD', NULL, '2022-02-21 10:53:30', '2022-02-21 23:41:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
