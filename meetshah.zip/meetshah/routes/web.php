<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/
Auth::routes();

Route::group(['middleware' => 'check-permission:shop'], function() {
    Route::group(['prefix' => 'seller'], function () {
        Route::get('products', ['as' => 'seller.products', 'uses' => 'seller\ProductController@index']);
        Route::post('getproducts', ['as' => 'seller.getproducts', 'uses' => 'seller\ProductController@getproducts']);
        Route::get('product/{id}', ['as' => 'seller.product.edit', 'uses' => 'seller\ProductController@edit']);
    });
});

Route::group(['middleware' => 'check-permission:user'], function() {
    
    Route::get('/home', 'ProductsController@index')->name('home');
    Route::get('/', 'ProductsController@index');
    Route::get('cart', 'ProductsController@cart');
    Route::get('add-to-cart/{id}', 'ProductsController@addToCart');
    Route::patch('update-cart', 'ProductsController@update');
    Route::delete('remove-from-cart', 'ProductsController@remove');
    Route::get('checkout', 'ProductsController@checkout');
    Route::get('clear-cart', 'ProductsController@clearcart');
    Route::get('confirm-order', 'ProductsController@confirmorder');
    Route::get('my-order', 'ProductsController@myorder');
});
Route::get('activelanguage/{lang}', ['as' => 'activelanguage', 'uses' => 'HomeController@activelanguage']);

//Route::get('/home', 'HomeController@index')->name('home');
